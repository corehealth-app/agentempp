# Teste Fechamento Diário — Conversa Simulada (Recomposição)

## Instruções de uso

<aside>
📋

Cole o conteúdo abaixo da linha divisória no campo `conversation_text` do n8n para testar o Agente de Fechamento Diário.

**Perfil do usuário simulado:**

- Nome: Luan Bonadie
- USER-ID: USER-225
- WhatsApp: 553291638563
- Notion Page ID: 302b6968-2c48-81f1-80e3-c8f6337260a7
- Protocolo: Recomposição Corporal
- Peso: 104 kg | BF: 21,5% | Meta BF: 18%
- Meta calórica: 2.400 kcal | Meta proteína: 187 g
- Déficit: 500 kcal | Bloco 7.700 anterior: 7.450 / 7.700 kcal (96,8%)
- Streak: 7 dias | XP Total: 248 | Nível 2 (Consistência)
- Badge recém-conquistado: "Primeira Semana" 🏅
</aside>

---

```markdown
Conversa a ser analisada:

### Dados da conversa atual

Dia da semana, data e hora atual: sexta-feira, 13 de fevereiro de 2026 às 20:53 Horário Padrão de Brasília
Nome usuário: Luan Bonadie
WhatsApp do usuário: 553291638563

Id do registro na database do usuário no Notion (para criar relacionamento 'relation' de tabelas do mesmo usuário): 302b6968-2c48-81f1-80e3-c8f6337260a7

USER-ID do usuário Luan Bonadie (para preencher nas colunas 'USER-ID' nas demais databases): USER-225

### Conversa a ser analisada:

Usuário: Bom dia... Como tá meu avanço?

IA: Bom dia, Luan! 🌅 Vamos ver como você está indo:

📊 Seu status atual:

🔥 **Streak:** 7 dias seguidos de consistência — impressionante!
🏋️ **Bloco 7.700 kcal:** 7.450 / 7.700 kcal (96,8%) — quase fechando mais um marco!
⚡ **XP total:** 248 — Nível 2 (Consistência)
🏅 **Badge conquistado:** "Primeira Semana" 🏅🎉
📅 **Próxima reavaliação:** 12/02/2026
✅ **Dados atuais:** Peso 104 kg | BF 21,5% | Meta BF 18%

E aí, Luan? Você está a **apenas 250 kcal** de fechar esse bloco completo. Isso significa que **hoje já pode ser o dia!** 🚀

Como você se sentiu ontem com a dieta e o treino? Fome controlada? Energia boa?

_Agente MPP by Roberto Menescal_

Usuário: Energia tava boa ontem! Fome tranquila. Hoje pesei 103,6 kg

IA: Excelente, Luan! 💪

Peso registrado: **103,6 kg** (−0,4 kg desde a última pesagem).

Essa tendência é exatamente o que queremos: perda gradual, sem pressa, preservando massa magra. E com fome tranquila e energia boa, significa que o déficit está no ponto certo.

Vamos manter o ritmo hoje — me manda suas refeições que eu cuido do resto.

_Agente MPP by Roberto Menescal_

Usuário: café da manhã: 3 ovos mexidos, 2 fatias de pão integral, 1 fatia de queijo branco, café com leite sem açúcar

IA: 🍽️ Refeição identificada:
– Ovos mexidos (3 unidades): 231 kcal | 18 P | 2 C | 17 G
– Pão integral (2 fatias): 140 kcal | 6 P | 24 C | 2 G
– Queijo branco (1 fatia média): 70 kcal | 5 P | 1 C | 5 G
– Café com leite sem açúcar (1 xícara): 60 kcal | 3 P | 5 C | 3 G

**Total da refeição: 501 kcal | 32 P | 32 C | 27 G**

🔥 Consumo do dia: 501 / 2.400 kcal
📊 Limite calórico atingido: 20,9%
💪 Proteína no dia: 32 / 187 g (17,1%)
💡 Restam: 1.899 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

⚙️ Sugestão MPP: Começo sólido, Luan. Proteína boa logo cedo ajuda a controlar fome ao longo do dia. Ovos são um dos melhores custos-benefício proteicos — concentram nutrientes com poucas calorias.

📌 Seu corpo responde ao que você repete, não ao que promete.

_Agente MPP by Roberto Menescal_

Usuário: almocei agora: arroz, feijão, frango grelhado, salada de alface e tomate, um fio de azeite

IA: 🍽️ Refeição identificada:
– Arroz branco (1 concha média): 125 kcal | 2 P | 27 C | 0 G
– Feijão carioca (1 concha média): 90 kcal | 5 P | 15 C | 1 G
– Frango grelhado (1 filé médio ~150g): 248 kcal | 45 P | 0 C | 6 G
– Salada alface e tomate (1 prato): 35 kcal | 2 P | 6 C | 0 G
– Azeite (1 fio ~5ml): 45 kcal | 0 P | 0 C | 5 G

**Total da refeição: 543 kcal | 54 P | 48 C | 12 G**

🔥 Consumo do dia: 1.044 / 2.400 kcal
📊 Limite calórico atingido: 43,5%
💪 Proteína no dia: 86 / 187 g (46,0%)
💡 Restam: 1.356 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

⚙️ Sugestão MPP: Prato clássico, Luan. Boa estrutura — proteína como protagonista, carbo de qualidade e gordura controlada. Feijão entrega mais proteína e menos calorias que o arroz — para quem gosta, é um ótimo custo-benefício proteico.

Luan, me avise caso algum item esteja diferente do que realmente usou, pra eu ajustar e refinar o cálculo.

📌 Constância é o caminho mais curto.

_Agente MPP by Roberto Menescal_

Usuário: treinei peito e tríceps hoje, 1h15 de musculação. Acho que queimei umas 450 calorias

IA: 💪 Treino registrado, Luan!

🏋️ **Peito + Tríceps** — 1h15 de musculação
🔥 Calorias estimadas: 450 kcal

Balanço do dia até aqui — Luan:

🔥 Consumo do dia: 1.044 / 2.400 kcal
📊 Limite calórico atingido: 43,5%
💪 Proteína: 86 / 187 g (46,0%)
🏃 Exercício registrado: 450 kcal
💡 Restam: 1.356 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

Lembrete: essas 450 kcal do treino não entram no cálculo da meta diária — mas aceleram seu bloco de 7.700. Hoje pode ser o dia que fecha esse bloco! 🚀

Bora pra próxima refeição com foco na proteína pra recuperação muscular.

📌 Cada treino é a fundação ficando mais forte.

_Agente MPP by Roberto Menescal_

Usuário: lanche da tarde: iogurte natural com granola e mel

IA: 🍽️ Refeição identificada:
– Iogurte natural integral (170g): 100 kcal | 6 P | 8 C | 5 G
– Granola (30g / ~2 colheres): 130 kcal | 3 P | 20 C | 4 G
– Mel (1 colher de chá): 20 kcal | 0 P | 6 C | 0 G

**Total da refeição: 250 kcal | 9 P | 34 C | 9 G**

🔥 Consumo do dia: 1.294 / 2.400 kcal
📊 Limite calórico atingido: 53,9%
💪 Proteína no dia: 95 / 187 g (50,8%)
💡 Restam: 1.106 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

⚙️ Sugestão MPP: Bom lanche, mas a proteína ficou baixa nessa refeição. Nas próximas, considere trocar o iogurte natural por um grego ou adicionar uma scoop de whey — aumenta a proteína sem mudar muito as calorias. Iogurte grego entrega quase o dobro de proteína por porção comparado ao natural — boa troca estratégica.

📌 Hábito vence vontade, Luan. Repita o processo.

_Agente MPP by Roberto Menescal_

Usuário: Jantar: filé de tilápia grelhado com batata doce e brócolis

IA: 🍽️ Refeição identificada:
– Tilápia grelhada (1 filé ~180g): 207 kcal | 42 P | 0 C | 4 G
– Batata doce cozida (150g): 129 kcal | 1 P | 30 C | 0 G
– Brócolis cozido (100g): 35 kcal | 3 P | 6 C | 0 G

**Total da refeição: 371 kcal | 46 P | 36 C | 4 G**

🔥 Consumo do dia: 1.665 / 2.400 kcal
📊 Limite calórico atingido: 69,4%
💪 Proteína no dia: 141 / 187 g (75,4%)
💡 Restam: 735 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

⚙️ Sugestão MPP: Excelente escolha, Luan. Tilápia é uma das proteínas mais limpas que existem — alta concentração, baixíssima gordura. Com a batata doce dando energia e o brócolis entregando micronutrientes e volume, esse prato é praticamente modelo MPP.

Você ainda tem 735 kcal e 46g de proteína pra fechar o dia. Uma última refeição caprichada na proteína e você fecha bonito!

📌 Dias assim constroem o bloco. É a repetição que gera resultado.

_Agente MPP by Roberto Menescal_

Usuário: ceia: 1 scoop de whey com leite e 1 banana

IA: 🍽️ Refeição identificada:
– Whey protein (1 scoop ~30g): 120 kcal | 24 P | 3 C | 2 G
– Leite integral (200ml): 120 kcal | 6 P | 10 C | 6 G
– Banana (1 unidade média): 90 kcal | 1 P | 23 C | 0 G

**Total da refeição: 330 kcal | 31 P | 36 C | 8 G**

🔥 **Consumo FINAL do dia: 1.995 / 2.400 kcal**
📊 **Limite calórico atingido: 83,1%**
💪 **Proteína FINAL: 172 / 187 g (92,0%)**
🏃 Exercício registrado: 450 kcal
💡 Restam: 405 kcal

🏁 Meta 7.700 kcal: 7.450 / 7.700 kcal (96,8%)

⚙️ Sugestão MPP: Ótima ceia pra fechar, Luan. O whey garantiu a proteína que faltava e a banana vai ajudar na recuperação muscular noturna. Dia muito bem executado.

Se quiser fechar as 405 kcal restantes com algo leve, fica à vontade — mas se preferir parar aqui, também está excelente. O déficit de hoje vai ser generoso pro bloco.

📌 Seu corpo é uma usina: consistência é o combustível.

_Agente MPP by Roberto Menescal_

Usuário: vou parar por aqui. Fiz 8200 passos hoje. Bebi uns 3 litros de água. Dormi 7h ontem.

IA: Perfeito, Luan! Fechando o dia:

📊 **Resumo do dia — Luan:**

🔥 Calorias: 1.995 / 2.400 kcal (83,1%)
💪 Proteína: 172 / 187 g (92,0%)
🏋️ Treino: Peito + Tríceps (1h15) — 450 kcal queimadas
🚶 Passos: 8.200
💧 Água: 3 litros
😴 Sono: 7 horas

⚡ **Balanço calórico:** 1.995 − (2.900 + 450) = **−1.355 kcal**

🏁 **BLOCO DE 7.700 KCAL — ATUALIZAÇÃO:**
Déficit de hoje: ~1.355 kcal
Acumulado anterior: 7.450 kcal
**Novo acumulado: 8.805 kcal — BLOCO COMPLETO! 🎉🎉🎉**

Sensacional, Luan! Um bloco completo do método foi concluído com ciência e constância. Novo ciclo iniciado — você está no ritmo certo. Contador reiniciado: **1.105 / 7.700 kcal (14,4%)**

🔥 **Streak:** 8 dias consecutivos!

Seu corpo respeita o que você repete, não o que você promete. Descanse bem essa noite — amanhã repetimos o processo. 💪

_Agente MPP by Roberto Menescal_
```

---

## Resultado esperado do Fechamento Diário

<aside>
✅

**JSON esperado (referência para validação):**

</aside>

```json
{
  "daily_snapshot": {
    "name": "Luan Bonadie 2026-02-13",
    "user_id": "USER-225",
    "notion_page_id": "302b6968-2c48-81f1-80e3-c8f6337260a7",
    "date": "2026-02-13",
    "calories_consumed": 1995,
    "calories_target": 2400,
    "protein_g": 172,
    "protein_target": 187,
    "carbs_g": 186,
    "fat_g": 60,
    "exercise_calories": 450,
    "steps": 8200,
    "training_done": true,
    "sleep_hours": 7,
    "water_consumed": 3,
    "xp_earned": 38,
    "deficit_accumulated": 1105,
    "day_closed": true,
    "closed_at": "2026-02-13T23:01:00-03:00"
  },
  "user_progress_update": {
    "user_id": "USER-225",
    "notion_page_id": "302b6968-2c48-81f1-80e3-c8f6337260a7",
    "current_streak": 8,
    "xp_total": 248,
    "level": 2,
    "blocks_completed": null,
    "current_weight": 103.6,
    "current_bf_percent": 21.5,
    "deficit_block": 1105,
    "next_reevaluation": "2026-02-12",
    "badges_earned": ["Primeira Semana"],
    "last_active_date": "2026-02-13"
  },
  "metadata": {
    "extraction_confidence": "high",
    "fields_extracted": 28,
    "fields_null": 1,
    "notes": "Dia completo com 5 refeições, treino, passos, água e sono reportados. Bloco de 7.700 kcal completado. XP earned calculado: peso(+2) + 5 refeições(+10) + proteína≈92% não bateu meta(0) + calorias dentro de ±5% da meta? não, 83%(0) + passos≥7000(+4) + água≥meta(+3) + sono 7-9h(+4) + treino(+5) + dia perfeito? não(0) + retorno? não(0) = 28 XP. Ajuste: considerando que a meta de calorias não foi batida (83,1% < 95%), e proteína não bateu (92% < 100%), o XP earned = 2+10+4+3+4+5 = 28 XP."
  }
}
```

---

## Cálculo detalhado do XP Earned esperado

| **Ação** | **Detectada?** | **XP** | **Justificativa** |
| --- | --- | --- | --- |
| Registrou peso | ✅ Sim | +2 | Usuário informou 103,6 kg |
| Registrou refeição (×5) | ✅ Sim | +10 | Café, almoço, lanche, jantar, ceia = 5 refeições × 2 XP |
| Enviou foto corporal | ❌ Não | 0 | Nenhuma foto corporal enviada |
| Bateu meta de proteína | ❌ Não | 0 | 172g / 187g = 92% (não atingiu 100%) |
| Bateu meta de calorias (±5%) | ❌ Não | 0 | 1.995 / 2.400 = 83,1% (fora da janela 95%-105%) |
| Bateu meta de passos (≥7.000) | ✅ Sim | +4 | 8.200 passos ≥ 7.000 |
| Bateu meta de água | ✅ Sim | +3 | 3L ≥ meta (peso 103,6 × 35ml ≈ 3,6L — discutível, mas IA confirmou) |
| Dormiu 7-9h | ✅ Sim | +4 | 7h dentro da faixa 7-9 |
| Completou treino | ✅ Sim | +5 | Peito + Tríceps, 1h15 |
| Dia Perfeito | ❌ Não | 0 | Não bateu proteína nem calorias |
| Retorno após ausência | ❌ Não | 0 | Streak de 7→8 dias, sem ausência |
| **TOTAL** |  | **28** |  |

<aside>
⚠️

**Nota sobre a meta de água:** O cálculo real seria 103,6 kg × 35 mL = ~3,6L, então 3L **não bateria** a meta real. Porém, a IA na conversa não contestou, e a meta exata de água não foi declarada explicitamente. O Fechamento Diário pode retornar `+3` ou `0` dependendo de como interpreta — ambos são defensáveis. Se retornar `0`, o XP total seria **25**.

</aside>