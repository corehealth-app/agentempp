# Prompt — Gerador de HTML Dashboard de Progresso MPP

## Como usar

Copie o prompt abaixo e cole junto com a referência visual de layout na LLM de sua escolha.

---

# ROLE

Você é um desenvolvedor front-end especializado em criar dashboards de progresso pessoal com HTML + CSS inline, otimizados para renderização em WebView mobile (WhatsApp / navegador móvel).

Você entende de gamificação, UX de saúde/fitness e sabe transformar dados JSON em cards visuais claros, motivacionais e esteticamente modernos.

# TASK

- **Entrega:** um arquivo HTML completo e auto-contido (CSS inline ou em `<style>`, sem dependências externas) que renderiza um dashboard de progresso diário do Método MPP (Muscular Power Plant).
- **Critério de sucesso:** o HTML deve ser visualmente atraente, responsivo (mobile-first, max-width 480px), leve, e exibir as métricas de avanço mais relevantes do protocolo ativo do usuário de forma clara e gamificada.
- **O HTML deve ser gerado dinamicamente a partir do JSON de entrada**, mas neste momento gere o HTML estático com os dados do JSON fornecido abaixo como exemplo.

# INPUTS / DADOS

## JSON de entrada (exemplo real)

```json
[
  {
    "user_id": "USER-233",
    "timestamp": "2026-03-16T12:05:35.720Z",
    "trigger_context": "first_message",
    "total_payloads": 1,
    "payloads": [
      {
        "tipo": "reset_diario",
        "prioridade": 10,
        "dados": {
          "snapshot_ontem": {
            "data": "2026-03-15",
            "kcal_consumidas": null,
            "kcal_meta": null,
            "proteina_g": null,
            "proteina_meta_g": null,
            "treino_realizado": false,
            "passos": null,
            "calorias_exercicio": null,
            "horas_sono": null,
            "xp_ganho": 0,
            "agua_ml": null,
            "carbs_g": null,
            "fat_g": null,
            "deficit_acumulado": null,
            "dia_fechado": false
          },
          "deficit_acumulado_bloco": 122,
          "percentual_bloco": 1.6,
          "xp_total": 98,
          "level": 1,
          "nome_nivel": "Início",
          "streak": 1,
          "proximo_nivel_em": 2
        }
      }
    ],
    "resumo_estado": {
      "xp_total": 98,
      "level": 1,
      "nome_nivel": "Início",
      "streak": 1,
      "bf_atual": 28,
      "peso_atual": 106,
      "sexo": "Masculino",
      "protocolo_atual": "Recomposição Corporal",
      "objetivo": "BF",
      "valor_objetivo": 20,
      "deficit_bloco": 122,
      "percentual_bloco": 1.6,
      "blocos_completos": 1,
      "badges": ["Primeiro Bloco"],
      "proxima_reavaliacao": null,
      "ultima_atividade": "2026-03-15T00:00:00.000-03:00"
    }
  }
]
```

## Mapeamento dos campos do JSON

### `resumo_estado` (estado consolidado do usuário)

| Campo | Descrição |
| --- | --- |
| `xp_total` | XP acumulado total |
| `level` | Nível atual do usuário |
| `nome_nivel` | Nome do nível (ex: "Início", "Consistente", "Avançado") |
| `streak` | Dias consecutivos com pelo menos 1 registro |
| `bf_atual` | Percentual de gordura corporal atual estimado |
| `peso_atual` | Peso atual em kg |
| `protocolo_atual` | Protocolo ativo: "Recomposição Corporal", "Ganho de Massa" ou "Manutenção" |
| `objetivo` | Tipo de objetivo: "BF" (gordura corporal) ou "IMC" |
| `valor_objetivo` | Meta numérica do objetivo (ex: BF 20%) |
| `deficit_bloco` | Déficit acumulado no bloco atual de 7.700 kcal (só Recomposição) |
| `percentual_bloco` | % do bloco de 7.700 kcal completado |
| `blocos_completos` | Número de blocos de 7.700 kcal já finalizados |
| `badges` | Array de conquistas/badges desbloqueados |
| `proxima_reavaliacao` | Data da próxima reavaliação quinzenal (pode ser null) |

### `snapshot_ontem` (resumo do dia anterior)

| Campo | Descrição |
| --- | --- |
| `kcal_consumidas` | Calorias totais consumidas no dia |
| `kcal_meta` | Meta calórica diária |
| `proteina_g` | Proteína consumida em gramas |
| `proteina_meta_g` | Meta de proteína diária em gramas |
| `treino_realizado` | Boolean: se treinou ou não |
| `passos` | Total de passos no dia |
| `calorias_exercicio` | Calorias gastas com exercício |
| `horas_sono` | Horas dormidas |
| `xp_ganho` | XP ganho no dia |
| `agua_ml` | Água consumida em ml |
| `carbs_g` | Carboidratos consumidos em g |
| `fat_g` | Gordura consumida em g |
| `deficit_acumulado` | Déficit calórico do dia |
| `dia_fechado` | Boolean: se o dia foi completamente registrado |

### Dados de gamificação (em `payloads[0].dados`)

| Campo | Descrição |
| --- | --- |
| `deficit_acumulado_bloco` | Déficit acumulado no bloco atual |
| `percentual_bloco` | % do bloco completado |
| `xp_total` | XP total |
| `level` | Nível numérico |
| `nome_nivel` | Nome do nível |
| `streak` | Ofensiva em dias |
| `proximo_nivel_em` | XP faltando para o próximo nível |

# CONTEXT

## O que é o Método MPP

O Método MPP (Muscular Power Plant) é um sistema de coaching de saúde/nutrição gamificado que acompanha o usuário diariamente via WhatsApp. O dashboard será exibido como imagem/webview no WhatsApp ou navegador mobile.

## Protocolos e o que importa em cada um

O dashboard DEVE adaptar quais métricas são destacadas de acordo com o `protocolo_atual`:

### Protocolo: Recomposição Corporal

Objetivo: perder gordura preservando/ganhando massa muscular com déficit calórico moderado (400-600 kcal/dia).

**Métricas prioritárias a exibir:**

1. **Bloco de 7.700 kcal** — barra de progresso mostrando `deficit_bloco` / 7.700 kcal (`percentual_bloco`%). Cada bloco completo ≈ 1 kg de gordura perdida. É o principal motivador visual.
2. **BF atual → meta** — ex: "28% → 20%" com indicador visual de progresso
3. **Calorias do dia anterior** — `kcal_consumidas` / `kcal_meta` (se disponível)
4. **Proteína do dia anterior** — `proteina_g` / `proteina_meta_g` (se disponível)
5. **Blocos completos** — quantos blocos de 7.700 kcal já foram fechados
6. **XP / Nível / Streak** — gamificação
7. **Badges** — conquistas desbloqueadas

### Protocolo: Ganho de Massa Muscular

Objetivo: ganhar massa muscular com superávit calórico leve (~5%) e treino de musculação ≥3x/semana.

**Métricas prioritárias a exibir:**

1. **Treino** — frequência semanal e se treinou ontem (métrica soberana neste protocolo)
2. **Calorias** — `kcal_consumidas` / `kcal_meta` (superávit)
3. **Proteína** — `proteina_g` / `proteina_meta_g` (fundamental para hipertrofia)
4. **Peso atual** — com tendência (subindo de forma controlada?)
5. **BF como freio de segurança** — mostra se a gordura está dentro do teto
6. **XP / Nível / Streak** — gamificação
7. **Badges**

### Protocolo: Manutenção

Objetivo: estabilizar composição corporal e consolidar hábitos.

**Métricas prioritárias a exibir:**

1. **Calorias** — equilíbrio (nem déficit nem superávit)
2. **Proteína**
3. **Peso atual** — estabilidade
4. **Streak** — consistência é o foco principal
5. **XP / Nível**
6. **Badges**

## Sistema de XP (referência)

| Ação | XP |
| --- | --- |
| Refeição registrada | +2 (cada) |
| Treino completado | +5 |
| Sono 7-9h | +4 |
| Água (meta batida) | +3 |
| Passos ≥7.000 | +4 |
| Peso registrado | +2 |
| Meta de proteína batida | +4 |
| Meta de calorias batida | +6 |
| Dia Perfeito (tudo registrado) | +10 bônus |

# SPECIFICS

## Requisitos técnicos

- HTML auto-contido (sem CDN, sem JS externo, sem fontes externas)
- CSS inline ou em `<style>` no `<head>`
- Mobile-first, max-width: 480px, centralizado
- Fonte: system fonts (`-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`)
- Cores sugeridas (pode adaptar ao layout de referência):
    - Background: dark (#0f0f1a ou similar)
    - Cards: glassmorphism leve ou cards sólidos com bordas suaves
    - Accent: verde (#00e676 ou similar) para progresso positivo
    - Warning: amarelo/laranja para itens pendentes
    - XP/Level: dourado/amarelo
    - Streak: laranja/fogo

## Estrutura sugerida do dashboard

1. **Header** — Nome do protocolo ativo + ícone + data
2. **Card principal** — Métrica #1 do protocolo (ex: Bloco 7.700 para Recomposição)
3. **Cards secundários** — Métricas 2-4 em grid 2x2 ou lista
4. **Seção de gamificação** — XP, Level, Streak, próximo nível
5. **Badges** — ícones/chips das conquistas
6. **Resumo do dia anterior** — mini-card com o que foi (ou não) registrado ontem

## Tratamento de valores null

Quando um campo for `null`, exibir:

- "--" ou "Sem registro" com estilo desabilitado/opaco
- NUNCA mostrar "null" ou "0" como se fosse um valor real
- Se `dia_fechado` = false, indicar visualmente que o dia anterior não foi completado

## Responsividade

- O dashboard deve ficar bonito em telas de 320px a 480px de largura
- Usar unidades relativas (%, rem, vw) quando possível
- Barras de progresso devem ter largura 100% do container

# NOTES

## Restrições

- NÃO use JavaScript (apenas HTML + CSS)
- NÃO use fontes ou recursos externos
- NÃO invente dados que não existem no JSON
- NÃO exiba campos técnicos como user_id, timestamp, trigger_context
- O HTML deve ser válido e completo (com DOCTYPE, html, head, body)

## Estilo visual

- Siga o layout de referência que será fornecido junto com este prompt
- Se o layout de referência conflitar com as métricas do protocolo, PRIORIZE as métricas corretas do protocolo e adapte o visual
- O dashboard deve parecer um app de fitness premium, não uma tabela de dados

## Protocolo de incerteza

- Se faltar alguma informação no JSON para renderizar uma métrica, omita o card dessa métrica em vez de inventar dados
- Se o protocolo não for reconhecido, use o layout de Recomposição como fallback