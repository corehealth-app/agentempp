# Coleta de Dados

User Input: reset_chat
Response Obtained: Pronto! Seu chat foi resetado.

Estou pronto para começar um novo cadastro. Qual é o seu nome?
Model Used: xiaomi/mimo-v2-flash
Session ID: chat_mpp_live_1_553291638563
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Luan Bonadie - 553291638563
WhatsApp: 553291638563