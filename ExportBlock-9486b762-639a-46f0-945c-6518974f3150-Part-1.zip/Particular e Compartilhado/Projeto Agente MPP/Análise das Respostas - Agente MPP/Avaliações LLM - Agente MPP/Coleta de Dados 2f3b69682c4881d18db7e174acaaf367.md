# Coleta de Dados

User Input: ta
Response Obtained: Rafael, qual sexo biológico devemos usar para os cálculos metabólicos? (masculino/feminino)
Model Used: xiaomi/mimo-v2-flash:free
Session ID: chat_mpp_live_1_558396965991
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Rafael - 558396965991
WhatsApp: 558396965991