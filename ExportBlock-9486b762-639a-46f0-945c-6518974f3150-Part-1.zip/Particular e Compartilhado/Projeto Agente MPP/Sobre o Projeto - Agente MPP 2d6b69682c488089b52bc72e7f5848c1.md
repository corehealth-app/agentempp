# Sobre o Projeto - Agente MPP

## Resumo do projeto

O **Agente MPP** é um ecossistema de automação e IA conversacional, implementado em **n8n**, que operacionaliza o **Método MPP — Muscular Power Plant** como um atendimento contínuo via WhatsApp. O sistema combina governança de conversa baseada em **neurociência comportamental**, regras clínicas/nutricionais, **gamificação** e **monetização por assinatura** — tudo orquestrado por **múltiplos agentes especializados** que conduzem o usuário por **3 protocolos distintos** (Recomposição Corporal, Ganho de Massa e Manutenção).

Em termos práticos, ele transforma mensagens (texto, áudio e imagem) em **decisões e respostas guiadas**, mantendo o usuário em execução diária (dieta, treino e hábitos), sem transferir a ele a carga de "fazer contas", organizar plano ou interpretar métricas. A cada **14 dias**, o sistema executa uma **reavaliação quinzenal** com coleta de peso, fotos e dados comportamentais, recalculando metas de forma determinística.

---

## Finalidade e promessa do sistema

O projeto existe para **acompanhar, corrigir e orientar** o usuário "todos os dias", com linguagem clara, direta e responsável, reforçando microvitórias e consistência — e não atalhos ou promessas. O onboarding prioriza **pedir o nome antes de qualquer resposta**, mesmo que o usuário chegue com uma dúvida técnica, para ativar identidade e reduzir fricção cognitiva.

---

## Os 3 protocolos do método

O MPP opera com **3 fases formalizadas** — todo usuário está sempre em uma delas, nunca "sem fase". A transição entre elas é guiada pelo agente com base em critérios objetivos e decisão consciente do usuário.

### 1. Recomposição Corporal

- **Objetivo:** Perda de gordura com preservação/ganho muscular
- **Critérios de entrada:** BF ≥ 20% (homens) ou ≥ 28% (mulheres); IMC ≥ 25 quando BF não disponível
- **Déficit:** 400–600 kcal/dia, calibrado por perfil comportamental de fome
- **Mecânica central:** Blocos de 7.700 kcal como referência de progresso (≈ 1 kg de gordura)
- **Escada de metas:** BF > 30% → reduzir 10pp; depois 18% → 15% → 10% (com checkpoints decisórios)
- **Reverse Diet:** Transição obrigatória para Manutenção com subida gradual de +100 kcal/semana até zerar o déficit (nunca pular direto para meta de manutenção)

### 2. Ganho de Massa Muscular

- **Objetivo:** Hipertrofia prioritária com controle de gordura
- **Critérios de entrada:** BF ≤ 19% (H) ou ≤ 27% (M); IMC ≤ 24; musculação ≥ 3x/semana
- **Meta calórica:** TDEE × 1,05 (superávit leve = ganho limpo)
- **Limites de segurança:** +3pp BF (homens), +4pp BF (mulheres), ou +1,5 IMC

### 3. Manutenção

- **Objetivo:** Estabilização, consolidação e prevenção de recaída
- **Critérios de entrada:** Já está na faixa saudável; não deseja reduzir ou ganhar; precisa estabilizar antes de nova fase
- **Meta calórica:** BMR × fator de atividade (TDEE neutro)
- **Recálculo:** Apenas quando frequência semanal de treino muda (com mapeamento explícito de frequência → fator de atividade)
- **Mensagem de boas-vindas:** Obrigatória na primeira interação após transição, com apresentação das metas de kcal, proteína, água, sono e treino
- **Entrada via Reverse Diet:** Suporte a usuários vindos da Recomposição com metas intermediárias semanais (+100 kcal/semana) até manutenção plena

---

## Reavaliação quinzenal

Pilar central de cada protocolo. A cada 14 dias, o agente executa uma sessão estruturada com **perguntas fixas** (peso atual, fotos corporais, dado comportamental e nível de atividade física). O protocolo de Recomposição usa 4 perguntas (peso, fotos, fome, frequência de atividade física); o Ganho de Massa também usa 4 (peso, fotos, frequência de treino, nível de atividade física); a Manutenção usa 3 (peso, fotos, frequência de treino). Com base nesses dados, o sistema:

- Recalcula metas calóricas quando necessário
- Avalia tendência de composição corporal (por BF estimado ou IMC)
- Decide migração automática entre protocolos (ex.: sair de Ganho para Recomposição se ultrapassar limite de gordura)
- Comunica ajustes com tom neurocomportamental (tutor, sem julgamento)
- **Regra de prioridade (Recomp):** Ao processar dados da reavaliação, verificar PRIMEIRO se o usuário atingiu a faixa de normalidade (checkpoint) ANTES de comunicar metas de recomposição — evita misturar informações de transição com dados de continuidade

---

## Cálculos determinísticos

Os cálculos do MPP são executados de forma **determinística e auditável**, fora da LLM, por um servidor de cálculos dedicado. Os principais são:

- **BMR (Taxa Metabólica Basal):** Seleção automática entre Mifflin–St Jeor (padrão) e Katch–McArdle (quando há BF estimado confiável). O agente nunca revela qual fórmula foi usada.
- **TDEE:** BMR × fator de atividade (sedentário 1,20 → atleta 1,90)
- **Meta de Recomposição:** TDEE − déficit (400–600 kcal, baseado em fome)
- **Meta de Ganho:** TDEE × 1,05
- **Meta de Manutenção:** TDEE neutro
- **Balanço energético diário:** Calorias consumidas − TDEE (exercício entra no balanço, não reduz a meta)
- **Projeção de meta:** 1 kg de gordura ≈ 7.700 kcal (comunicada como referência conservadora)
- **IMC como proxy alternativo:** Quando não há fotos/BF, usa-se IMC com escada progressiva equivalente (IMC 23 → 22 → 21)

---

## 6 agentes/estágios configuráveis

O sistema não é um workflow monolítico — ele opera com **múltiplos agentes especializados**, cada um com prompt, modelo LLM, temperatura e regras próprias:

1. **Coleta de Dados** — Conduz o onboarding estruturado (perguntas uma por vez, ordem fixa) e coleta dados base para cálculos
2. **Recomposição Corporal** — "Médico-treinador" digital que guia o protocolo de déficit, blocos de 7.700 kcal e reavaliação
3. **Ganho de Massa** — Gerencia superávit controlado, limites de gordura e ciclos de 8–16 semanas
4. **Manutenção** — Estabiliza o usuário com orçamento de 14 dias e flexibilidade controlada
5. **Analista Diário (Fechamento Diário)** — Analista backend que transforma a conversa do dia em JSON estruturado (Daily Snapshot)
6. **Engajamento Ativo** — Mascote motivacional que envia nudges ultra curtos, sensíveis ao horário

Cada estágio é configurável via database de **Configurações do Agente MPP**, com suporte a múltiplos modelos LLM (Claude, GPT-4o, GPT-5, Gemini, Grok, DeepSeek e outros), temperature, max tokens, idioma e timezone por estágio.

---

## Design neurocomportamental (18+ mecanismos)

A linguagem e o comportamento do agente seguem um framework de **neurociência comportamental** com mecanismos explícitos e documentados:

1. **Reforço dopaminérgico imediato** — Microvitória a cada ação positiva, com elogios sempre variáveis (nunca repetir a mesma frase)
2. **Redução de carga cognitiva** — O agente decide pelo usuário; nunca pede cálculo; oferece opções A/B simples
3. **Reforço de identidade** — Foco em "quem o usuário é" (não só no que faz): "Você já está agindo como alguém que cuida do próprio corpo"
4. **Metas escalonadas (chunking)** — Sempre uma meta ativa por vez, microetapas executáveis
5. **Autonomia, competência e pertencimento** (Self-Determination Theory) — Escolha real, reforço de competência, senso de "não estar sozinho"
6. **Priming e gatilhos de ação** — Frases de preparação mental pré-treino; regras IF/THEN salvas e reutilizadas
7. **Reforço positivo variável** — Elogios curtos, longos, surpresas e frases motivacionais alternadas
8. **Acolhimento pós-falha** — Normalizar o erro, cortar o drama, puxar de volta pro eixo
9. **Previsibilidade saudável** — Ciclo diário previsível (manhã → proteína → pré-treino → pós-refeição → encerramento)
10. **Visualização proativa** — Descrição de sensações e mudanças estéticas ao atingir metas
11. **Storytelling e metáforas** — Analogias curtas que ativam sistema límbico
12. **Baixa fricção linguística** — Frases curtas, sem jargão, sem texto denso
13. **Arquitetura de escolha (nudge)** — Nunca perguntas abertas; sempre duas opções boas
14. **Consistência social** — Usar compromissos anteriores do próprio usuário
15. **Celebração estratégica** — Mensagem especial a cada bloco de 7.700 kcal completado
16. **Feedback inteligente periódico** — Comparação semanal/mensal com micro-ajustes
17. **Flexibilidade estratégica** — 10–15% das calorias semanais podem ser flexíveis
18. **Reavaliações como gatilho motivacional** — Fotos + peso + recálculo a cada 14 dias

---

## Regras-mãe do comportamento do agente

O Manual MPP define um conjunto de invariantes que estruturam o produto:

- **Onboarding obrigatório:** "primeiro o nome", depois capacidades, convite à personalização e só então a resposta do tema original.
- **Regra Anti-Genérico:** quando falta informação, o agente pergunta **uma coisa por vez**, confirma e avança — sem interrogatório e sem texto enlatado.
- **Carga cognitiva no agente, não no usuário:** é proibido pedir que o usuário some calorias/macros; o sistema deve devolver tudo pronto, com metas e parciais do dia.
- **Tom médico-treinador:** claro, direto, responsável e com humor na medida certa. Acolhedor mas firme. Nunca humilhar, julgar ou fazer terrorismo.
- **Perguntas automáticas ativas:** O agente envia proativamente perguntas sobre dieta (dia seguinte, semana, aderência), treino (satisfação, ajustes, frequência) e ajustes gerais — sempre em horários estratégicos.
- **Regra Anti-Proatividade:** Após registrar refeição ou exercício, o agente NÃO sugere a próxima refeição/treino a menos que o usuário peça. Lógica: responder → calcular → balanço → 1 sugestão curta → 1 frase motivacional → FIM. Aplicada em todos os 3 protocolos.
- **Proibições de linguagem:** Nunca transferir responsabilidade de cálculo; nunca tom julgador/moralista; nunca texto técnico desnecessário; nunca terrorismo nutricional.

---

## Banco de dados estruturado

O sistema é sustentado por **6 databases** que formam a espinha dorsal de dados:

<aside>
👤

**Users & Profiles**

</aside>

- **Users** — Tabela central de identificação (nome, telefone, email), configurações regionais (timezone, locale) e status da conta
- **User Profiles** — Perfil físico e dados de onboarding: sexo, nascimento, altura, peso, objetivo, status do fluxo de cadastro. Base para cálculos de TDEE e macros

<aside>
📈

**Gamificação**

</aside>

- **Daily Snapshots** — Registro diário de progresso: calorias consumidas/meta, proteína consumida/meta, passos, treino e XP ganho
- **User Progress** — XP total acumulado e nível atual por usuário

<aside>
💳

**Pagamentos**

</aside>

- **Subscriptions** — Controle de assinaturas e acesso (trial/mensal/anual), status, período e integração com Stripe
- **Subscription Events** — Auditoria de webhooks, checkouts, renovações e cancelamentos

---

## Sistema de gamificação

O MPP implementa um sistema completo de gamificação para manter engajamento:

- **XP Events:** Cada ação positiva gera XP (refeição logada, proteína batida, dia perfeito, streak, level up)
- **User Progress:** XP total acumulado e nível atual, atualizado automaticamente
- **Daily Snapshots:** Consolidação diária de todos os indicadores (calorias, proteína, passos, treino, XP)
- **Mascote evolutivo** (roadmap): Figuras estáticas por estágio de evolução, associadas ao progresso do usuário. Animações e stickers dinâmicos planejados para versão futura.

---

## Monetização e assinaturas

O projeto opera como **SaaS** com modelo de assinatura recorrente:

- **Planos:** Trial → Mensal → Anual
- **Gateway:** Stripe (conta temporária, com previsão de migração futura)
- **Controle de acesso:** Flag de status (trial/pago/expirado) com regras de limitação
- **Auditoria:** Log completo de eventos de assinatura para idempotência e rastreabilidade

---

## Dashboard de métricas

O sistema conta com um **dashboard operacional** com visões consolidadas:

- 👥 Usuários ativos
- ⭐ Últimos eventos de XP
- 📈 Progressão e gamificação (User Progress)
- 📊 Atividade recente (Daily Snapshots)
- 💳 Status de assinaturas
- 📜 Eventos de pagamento (auditoria)

---

## Arquitetura técnica (workflow n8n)

A base do projeto é um workflow n8n que conecta canal, memória, IA, persistência e fallback humano:

1. **Entrada e roteamento de mensagens** — Diferencia eventos incoming/outgoing, evita loops e separa rotas por tipo. Mecanismos de "pausar/reativar atendimento IA" quando a conversa precisa ser transferida.
2. **Bufferização e ordenação (antirruído de chat)** — Mensagens empilhadas em **Redis** como lista temporária de buffer, consolidando contexto e reduzindo fragmentação típica de WhatsApp.
3. **Suporte a áudio e imagem** — Áudio: transcrição via OpenAI + nota interna. Imagem: análise multimodal (avaliação corporal ou análise de refeição) com prompts especializados e dados estruturados.
4. **Geração de resposta e entrega no WhatsApp** — Suporte a dois provedores (Evolution e API oficial), selecionado por switch. Camada de **TTS via ElevenLabs** para converter texto em áudio otimizado para WhatsApp.
5. **Persistência e histórico** — Conversas em tabelas (chats/chat_messages) + memória de conversa em Postgres. Databases estruturadas no Notion (Users, Profiles, Snapshots, Progress, Subscriptions, Events).
6. **Base de conhecimento e RAG** — Vector Store em Supabase + pipeline de carregamento/splitting para respostas fundamentadas. Regras do agente documentadas em databases Notion separadas (Regras do Agente — 27/12/2025 e Regras do Agente de Coleta — 02/02/2026).
7. **Handoff humano** — Label/ação no Chatwoot para encaminhar conversa quando o usuário solicita atendente ou quando a operação decide.

---

## Documentação de regras

As regras operacionais do agente estão documentadas em **duas databases dedicadas** (não mais em um "promptão" único):

- **Regras do Agente (27/12/2025)** — Regras gerais, Recomposição Corporal, Ganho de Massa, Manutenção e Coleta de Dados
- **Regras do Agente de Coleta (02/02/2026)** — Regras específicas do fluxo de coleta de dados

Essa separação segue a estratégia de **fragmentação de prompt** para reduzir risco operacional e facilitar manutenção.

---

## O que torna este projeto "produto", e não apenas automação

A diferença central do Agente MPP é que ele não é um "chatbot genérico": ele é uma **implementação operacional completa do Método MPP**, com:

- **3 protocolos formalizados** com regras de entrada, execução, reavaliação e transição
- **Cálculos determinísticos** separados da LLM (auditáveis e reutilizáveis)
- **6 agentes especializados** com configurações independentes por estágio
- **Gamificação** com XP, níveis e Daily Snapshots
- **Monetização** via assinatura recorrente com Stripe
- **18+ mecanismos neurocomportamentais** que governam cada interação
- **Dashboard SaaS** para acompanhamento do negócio
- **Reavaliação quinzenal** como motor de progresso contínuo

O workflow é o motor; o Manual é a constituição; os agentes são os especialistas; e as integrações (WhatsApp/Chatwoot/Supabase/Redis/LLMs/TTS/Stripe) são a infraestrutura que viabiliza escala com rastreabilidade.