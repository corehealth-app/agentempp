# Dashboard - Métricas do Sistema

# Visão Geral do Sistema

## 👥 Usuários Ativos

## ⭐ XP Events (Últimos Eventos)

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%2067aa50e5579043d4a6db1e7fe820bc09.csv)

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%20534d0ac763c24fdf9eb24e31a9aa4760.csv)

---

## 📈 Progressão e Gamificação

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%205566d6d85ff54ac28265bf1d464ca50f.csv)

---

## 📊 Atividade Recente (Daily Snapshots)

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%20652b69e4a75e4ccda9c91edc2fdd4dde.csv)

---

---

## 💳 Status de Assinaturas

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%20e71e402a1b5046c6aee6f981764c610d.csv)

---

## 📜 Eventos de Pagamento (Auditoria)

[Sem título](Dashboard%20-%20M%C3%A9tricas%20do%20Sistema/Sem%20t%C3%ADtulo%20176651b935d7471ea26f60107a3d4799.csv)