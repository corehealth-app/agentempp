# Backoffice MPP — Especificação do Painel Administrativo

## Objetivo deste documento

Descrever de forma detalhada e funcional o **painel administrativo (backoffice)** que o dono do aplicativo MPP terá acesso ao migrar o sistema do Notion para uma aplicação nativa. Este documento serve como **especificação de produto** para a proposta de atualização do Agente MPP e como referência técnica para o desenvolvimento via vibe coding.

---

## Público-alvo do backoffice

**Dr. Roberto** — proprietário do método MPP e tomador de decisão do negócio. O painel deve permitir que ele:

- Visualize a saúde do aplicativo em tempo real
- Acompanhe usuários, engajamento e receita
- Gerencie os agentes de IA sem precisar de conhecimento técnico
- Tome decisões baseadas em dados (reter, escalar, ajustar)

---

## Estrutura geral — 7 módulos

O backoffice é organizado em **7 módulos funcionais**, cada um com propósito claro:

| Módulo | Função principal | Equivalente atual no Notion |
| --- | --- | --- |
| 1. Home / Visão Geral | KPIs consolidados + alertas | Dashboard Métricas (parcial) |
| 2. Gestão de Usuários | Cadastros, perfis, status | Users + User Profiles |
| 3. Gamificação | XP, níveis, snapshots diários | Daily Snapshots + User Progress |
| 4. Assinaturas e Pagamentos | Receita, planos, churn | Subscriptions + Subscription Events |
| 5. Configuração de Agentes | Modelos, prompts, parâmetros | Configurações do Agente MPP |
| 6. Qualidade das Respostas | Scores, análise LLM-as-Judge | Avaliações LLM - Agente MPP |
| 7. Logs e Auditoria | Eventos, erros, rastreabilidade | Subscription Events (parcial) |

---

# Módulo 1 — Home / Visão Geral

<aside>
🎯

**Propósito:** O Dr. Roberto abre o backoffice e, em menos de 10 segundos, sabe se o aplicativo está saudável.

</aside>

### KPIs principais (cards no topo)

Linha de cards com números grandes e indicador de tendência (↑↓→):

- **Usuários ativos** — Total de contas com status ativo (hoje vs. semana passada)
- **Novos cadastros (7d)** — Quantos completaram onboarding nos últimos 7 dias
- **Taxa de retenção (14d)** — % de usuários que enviaram pelo menos 1 mensagem nos últimos 14 dias
- **MRR (Monthly Recurring Revenue)** — Receita recorrente mensal ativa (trial não conta)
- **Churn rate (30d)** — % de cancelamentos nos últimos 30 dias
- **Score médio de qualidade** — Média dos scores LLM-as-Judge dos últimos 7 dias

### Gráficos de tendência

- **Gráfico de linha:** Novos cadastros por dia (últimos 30 dias)
- **Gráfico de área:** Usuários ativos diários (DAU) vs. usuários pagantes
- **Gráfico de barras:** Distribuição de usuários por protocolo ativo (Recomposição / Ganho / Manutenção)

### Alertas inteligentes

Banner no topo com alertas automáticos quando:

- Churn rate ultrapassar 10% no mês
- Score médio de qualidade cair abaixo de 3.5
- Mais de 5 usuários ficarem sem Daily Snapshot por 3+ dias consecutivos
- Algum agente estiver com status "Testing" ou "Archived" inesperadamente

---

# Módulo 2 — Gestão de Usuários

<aside>
👤

**Propósito:** Visualizar, buscar e inspecionar qualquer usuário do sistema.

</aside>

### Listagem principal

Tabela paginada com busca e filtros:

- **Colunas:** Nome, Telefone, Email, Protocolo Atual, Status da Conta, Plano, Data de Cadastro, Último Acesso
- **Filtros rápidos:** Por protocolo (Recomposição / Ganho / Manutenção), por plano (Trial / Mensal / Anual), por status (Ativo / Inativo / Expirado)
- **Busca:** Por nome, telefone ou email
- **Ordenação:** Por data de cadastro, último acesso, ou nome

### Perfil individual do usuário

Ao clicar em um usuário, abre uma página de detalhe com:

**Seção 1 — Dados pessoais e onboarding**

- Nome, telefone, email, timezone, locale
- Sexo, data de nascimento, altura, peso inicial, objetivo declarado
- Status do fluxo de onboarding (completo / em andamento / abandonado)
- Data de conclusão do onboarding

**Seção 2 — Métricas corporais atuais**

- Peso atual, BF estimado (ou IMC quando BF indisponível)
- Meta calórica ativa (e de qual protocolo vem)
- TDEE calculado, BMR, fator de atividade
- Próxima reavaliação quinzenal (data)

**Seção 3 — Histórico de reavaliações**

Tabela cronológica com cada reavaliação quinzenal:

- Data, peso registrado, BF/IMC, mudança de protocolo (se houve), ajuste calórico aplicado

**Seção 4 — Gamificação**

- XP total, nível atual, XP para próximo nível
- Últimos 10 eventos de XP
- Streak atual e maior streak

**Seção 5 — Assinatura**

- Plano atual, status, data de início, próxima cobrança
- Histórico de eventos de pagamento desse usuário

---

# Módulo 3 — Gamificação

<aside>
🏆

**Propósito:** Entender o engajamento real dos usuários e identificar quem está desengajando.

</aside>

### Visão consolidada

- **Ranking de XP** — Top 20 usuários por XP total (leaderboard)
- **Distribuição por nível** — Gráfico de barras mostrando quantos usuários estão em cada nível
- **XP médio por dia** — Tendência dos últimos 30 dias (indica saúde do engajamento)

### Daily Snapshots

Tabela de registros diários com filtros por:

- Usuário, data, protocolo ativo
- Indicadores: calorias consumidas/meta, proteína consumida/meta, passos, treinou (sim/não), XP do dia
- **Highlight automático:** Dias com meta calórica batida ficam em verde; dias sem registro ficam em vermelho

### Alertas de desengajamento

Lista de usuários que:

- Não têm Daily Snapshot há 3+ dias
- Tiveram queda de XP diário > 50% na última semana
- Perderam streak de 7+ dias

---

# Módulo 4 — Assinaturas e Pagamentos

<aside>
💳

**Propósito:** Controle financeiro, visibilidade de receita e gestão de churn.

</aside>

### KPIs financeiros (cards)

- **MRR** — Receita recorrente mensal
- **ARR** — Receita recorrente anual (projeção)
- **Total de assinantes ativos** — Por plano (trial / mensal / anual)
- **Churn rate** — Últimos 30 dias
- **LTV médio** — Lifetime Value estimado
- **Conversão trial → pago** — % dos últimos 30 dias

### Listagem de assinaturas

Tabela com:

- Usuário, plano, status (ativo / cancelado / expirado / trial), data de início, próxima cobrança, valor
- Filtros por plano, status, período
- Ação: ver detalhes do usuário

### Eventos de pagamento (auditoria)

Log cronológico de todos os eventos Stripe:

- Tipo de evento (checkout.completed, invoice.paid, subscription.canceled, etc.)
- Usuário, data/hora, valor, status de processamento
- Filtro por tipo de evento, usuário, período
- Flag de idempotência visível

### Gráficos

- **Gráfico de linha:** MRR ao longo do tempo (últimos 6 meses)
- **Gráfico de funil:** Trial → Ativo → Cancelado (conversão e churn)
- **Gráfico de pizza:** Distribuição por plano

---

# Módulo 5 — Configuração de Agentes

<aside>
⚙️

**Propósito:** Permitir que o Dr. Roberto (ou a equipe técnica) ajuste o comportamento dos agentes de IA sem tocar em código.

</aside>

### Listagem de agentes/estágios

Tabela com os 6 estágios configuráveis:

- **Colunas:** Config Name, Stage, Model, Temperature, Max Tokens, Status, Version, Default Language, Default Timezone, Wait Seconds Response, Updated At
- **Status visual:** Active (verde), Testing (amarelo), Archived (cinza)
- **Board view alternativa:** Agrupado por Status (Active / Testing / Archived)

### Editor de configuração

Ao clicar em um agente, abre formulário de edição com:

**Parâmetros do modelo**

- **Model** — Select com todos os modelos disponíveis (Claude, GPT-4o, GPT-5, Gemini, Grok, DeepSeek, etc.)
- **Temperature** — Slider de 0.0 a 1.0 com indicador visual
- **Max Tokens** — Input numérico com validação
- **Wait Seconds Response** — Tempo de espera antes de responder (simula digitação)

**Parâmetros regionais**

- **Default Language** — Select (pt-BR, en-US, es-ES)
- **Default Timezone** — Select com fusos horários

**Prompt do sistema**

- **Prompt System Image** — Campo de texto longo (prompt para análise de imagens)
- Área de visualização do prompt principal (read-only nesta versão, editável via proposta futura)

**Controle de versão**

- **Version** — Versionamento semântico (v1.0.0)
- **Status** — Toggle entre Active, Testing e Archived
- Histórico de alterações com timestamp e quem alterou

### Funcionalidades avançadas (roadmap)

- A/B testing entre modelos para o mesmo estágio
- Rollback instantâneo para versão anterior
- Comparação lado a lado de configurações

---

# Módulo 6 — Qualidade das Respostas (LLM-as-Judge)

<aside>
🧪

**Propósito:** Monitorar a qualidade das respostas do agente e identificar degradação antes que impacte o usuário.

</aside>

### Métricas de qualidade (cards)

- **Score médio (7d)** — Média ponderada dos últimos 7 dias
- **Score médio (30d)** — Tendência mensal
- **Total de avaliações** — Volume de avaliações realizadas
- **% de scores ≤ 2** — Taxa de respostas problemáticas

### Listagem de avaliações

Tabela com todas as avaliações LLM-as-Judge:

- **Colunas:** Agent Name, User Input, Response Obtained, Expected Response, Score, Reasoning, Model Used, Temperature, Evaluated At, Status
- **Filtros:** Por agente, por modelo, por score (1–5), por período, por status (Pendente / Avaliando / Avaliado)
- **Ordenação:** Por score (ascendente para ver piores primeiro) ou por data

### Visões analíticas

- **Board por Score** — Cards agrupados por nota (1, 2, 3, 4, 5) — permite ver rapidamente a distribuição
- **Board por Status** — Pendente / Avaliando / Avaliado
- **Gráfico de linha:** Score médio por dia (últimos 30 dias) — detectar degradação
- **Gráfico de barras:** Score médio por modelo — comparar performance entre LLMs
- **Gráfico de barras:** Score médio por agente/estágio — identificar qual agente precisa de ajuste

### Drill-down em avaliação

Ao clicar em uma avaliação, exibe:

- Input completo do usuário
- Resposta obtida (com formatação)
- Resposta esperada (ground truth)
- Reasoning do juiz (justificativa detalhada)
- Metadados: modelo, temperatura, max tokens, session ID, WhatsApp, data

---

# Módulo 7 — Logs e Auditoria

<aside>
📋

**Propósito:** Rastreabilidade total de eventos do sistema para debugging e compliance.

</aside>

### Tipos de log

- **Eventos de pagamento** — Webhooks Stripe, checkouts, renovações, cancelamentos (já existente em Subscription Events)
- **Eventos de agente** — Logs de execução dos workflows n8n (erros, timeouts, fallbacks)
- **Eventos de usuário** — Onboarding iniciado/completo/abandonado, mudança de protocolo, reavaliação realizada
- **Eventos de sistema** — Health checks, status dos provedores WhatsApp, status do Redis/Supabase

### Interface

Timeline cronológica unificada com:

- Filtro por tipo de evento, severidade (info / warning / error), usuário, período
- Busca por texto (session ID, nome, telefone)
- Exportação em CSV/JSON

---

# Requisitos de UX/UI

<aside>
🎨

**Princípios de design para o backoffice.**

</aside>

### Navegação

- **Sidebar fixa** com os 7 módulos como itens de menu
- **Breadcrumb** em cada página para contexto
- **Header** com nome do usuário logado, notificações e botão de logout

### Responsividade

- Desktop-first (o Dr. Roberto usará primariamente em computador)
- Responsivo para tablet (consultas rápidas)
- Mobile: apenas Home/KPIs e alertas

### Autenticação e permissões

- Login com email/senha + 2FA opcional
- **Papéis:**
    - **Admin (Dr. Roberto)** — Acesso total: todos os módulos, edição de agentes, visualização de dados
    - **Operador (equipe técnica)** — Acesso a: Configuração de Agentes, Qualidade, Logs
    - **Viewer** — Acesso somente leitura: Home, Usuários, Gamificação, Assinaturas

### Performance

- Dados do dashboard Home devem carregar em < 2 segundos
- Tabelas com paginação server-side (50 registros por página)
- Gráficos com lazy loading

---

# Mapeamento de dados: Notion → Backoffice

Correspondência direta entre as databases atuais do Notion e os módulos do backoffice:

| Database Notion | Módulo no Backoffice | Tipo de acesso | Observações |
| --- | --- | --- | --- |
| Users | Gestão de Usuários | Leitura + busca | Não editável pelo backoffice (dados vêm do WhatsApp) |
| User Profiles | Gestão de Usuários (detalhe) | Leitura | Métricas corporais, onboarding, cálculos |
| Daily Snapshots | Gamificação | Leitura + filtros | Base para alertas de desengajamento |
| User Progress | Gamificação | Leitura | XP total e nível — alimenta ranking |
| Subscriptions | Assinaturas e Pagamentos | Leitura | Fonte de verdade para MRR e churn |
| Subscription Events | Assinaturas + Logs | Leitura | Auditoria de webhooks Stripe |
| Configurações do Agente MPP | Configuração de Agentes | **Leitura + Escrita** | Único módulo com edição direta pelo admin |
| Avaliações LLM - Agente MPP | Qualidade das Respostas | Leitura + filtros | Scores e análise do LLM-as-Judge |

---

# Stack técnica sugerida

<aside>
💻

**Sugestão de tecnologias para o desenvolvimento nativo do backoffice.**

</aside>

- **Frontend:** Next.js (App Router) + Tailwind CSS + shadcn/ui (componentes prontos, responsivos)
- **Gráficos:** Recharts ou Tremor (integração nativa com React)
- **Backend/API:** Next.js API Routes ou tRPC (mesma stack, sem servidor separado)
- **Banco de dados:** PostgreSQL (já usado pelo n8n para chats) — migrar dados do Notion para tabelas SQL equivalentes
- **Autenticação:** NextAuth.js ou Clerk (suporte a 2FA)
- **Pagamentos:** Stripe SDK (já integrado)
- **Deploy:** Vercel ou Railway
- **Monitoramento:** Sentry para erros + Posthog para analytics de uso do backoffice

---

# Prioridade de implementação

<aside>
🚀

**Fases sugeridas para a proposta.**

</aside>

### Fase 1 — MVP do Backoffice

- [ ]  Home com KPIs consolidados (cards + gráficos básicos)
- [ ]  Listagem de usuários com busca e filtros
- [ ]  Perfil individual do usuário (dados + métricas + assinatura)
- [ ]  Listagem de assinaturas com status
- [ ]  Autenticação básica (email/senha)

### Fase 2 — Gestão e Qualidade

- [ ]  Configuração de agentes (listagem + editor)
- [ ]  Módulo de gamificação (ranking, snapshots, alertas)
- [ ]  Módulo de qualidade LLM-as-Judge (listagem + visões analíticas)
- [ ]  Alertas automáticos no Home

### Fase 3 — Operações e Escala

- [ ]  Logs e auditoria unificados
- [ ]  Gráficos avançados (MRR ao longo do tempo, funil de conversão)
- [ ]  Sistema de permissões (Admin / Operador / Viewer)
- [ ]  Exportação de dados (CSV/JSON)
- [ ]  A/B testing de modelos e rollback de configurações