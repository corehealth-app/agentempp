# Coleta de Dados

User Input: Feminino
Response Obtained: Luciana, já anotei que seu sexo é feminino. Agora preciso da sua idade.

**Quantos anos você tem hoje?**
Model Used: xiaomi/mimo-v2-flash
Session ID: chat_mpp_live_1_16892724870
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Luciana - 16892724870
WhatsApp: 16892724870