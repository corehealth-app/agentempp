# Coleta de Dados

User Input: 180
Response Obtained: Luan, e nível médio de atividade diária? Sedentário / Leve (1–3x/sem) / Moderado (4–5x/sem) / Alto (6–7x/sem) / Atleta (2x/dia)
Model Used: xiaomi/mimo-v2-flash
Session ID: chat_mpp_live_1_553291638563
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Luan Bonadie - 553291638563
WhatsApp: 553291638563