# Lógica de Análise de Protocolo — User Profiles

Esta página documenta a lógica completa de análise de protocolo implementada no n8n para o sistema MPP. O código analisa os dados do usuário e decide automaticamente qual protocolo deve ser seguido.

---

## 1. Visão Geral

O sistema usa duas métricas possíveis para definir metas:

| Métrica | Quando usar | Propriedades relacionadas |
| --- | --- | --- |
| **BF (Body Fat %)** | Quando o usuário informou percentual de gordura | `Body Fat Percent`, `LBM` |
| **IMC** | Fallback quando BF não está disponível | `IMC` (fórmula automática) |

As propriedades `Goal Type` e `Goal Value` armazenam o tipo e valor da meta calculada.

---

## 2. Fluxo de Decisão de Protocolo

```mermaid
flowchart TD
    A[Início] --> B{BF disponível?}
    B -->|Sim| C{BF >= limite?}
    B -->|Não| D{IMC >= 25?}
    
    C -->|Sim| E[Recomposição OBRIGATÓRIA]
    C -->|Não| F{Critérios comportamentais OK?}
    
    D -->|Sim| E
    D -->|Não| G{Critérios comportamentais OK?}
    
    F -->|Sim| H[Usuário PODE ESCOLHER]
    F -->|Não| E
    
    G -->|Sim| H
    G -->|Não| E
```

---

## 3. Limites por Sexo (BF)

| Parâmetro | Masculino | Feminino |
| --- | --- | --- |
| **Limite Recomposição** | ≥ 20% | ≥ 28% |
| **Limite Ganho de Massa** | ≤ 19% | ≤ 27% |
| **Faixa Saudável** | 15-19% | 23-27% |

---

## 4. Limites IMC (Universal)

| Parâmetro | Valor |
| --- | --- |
| **Limite Recomposição** | ≥ 25 |
| **Limite Ganho de Massa** | ≤ 24 |

---

## 5. Critérios Comportamentais para Ganho de Massa

Todos os critérios abaixo devem ser atendidos para liberar a escolha de protocolo:

- [ ]  Musculação ≥ 3x/semana (`Training Frequency >= 3`)
- [ ]  Sono ≥ 6h30/noite (calculado de `Bedtime` e `Wake Time`)
- [ ]  Alimentação estruturada (`Food Organization = "Sim"`)

---

## 6. Cálculo de Meta — Escada Progressiva

### 6.1 Meta de BF (Body Fat)

| BF Atual | Meta BF |
| --- | --- |
| > 30% | BF atual - 10 pontos |
| > 20% | 20% |
| > 18% | 18% |
| > 15% | 15% |
| ≤ 15% | 10% |

### 6.2 Meta de IMC (com margem mínima de 1 ponto)

| IMC Atual | Meta IMC | Observação |
| --- | --- | --- |
| ≥ 30 (e diferença ≥ 1) | 30 | Primeira escada |
| ≥ 25 (e diferença ≥ 1) | 25 | Segunda escada |
| ≥ 23 (e diferença ≥ 1) | 23 | Terceira escada |
| ≥ 22 (e diferença ≥ 1) | 22 | Quarta escada |
| < 22 | 21 | Meta final |

> ⚠️ **Regra de margem mínima**: Se a diferença entre o IMC atual e a meta da escada for < 1 ponto, o sistema pula para a próxima escada. Isso evita metas irrelevantes como "reduzir 0.1 ponto".
> 

**Exemplo**: IMC 30.1 → meta **25** (não 30, pois 30.1 - 30 = 0.1 < 1)

---

## 7. Fórmulas Relacionadas no Notion

### 7.1 Target Weight (Peso Alvo)

Calcula o peso que o usuário terá ao atingir a meta:

| Goal Type | Fórmula |
| --- | --- |
| **BF** | `LBM / (1 - Goal Value / 100)` |
| **IMC** | `Goal Value × (Height CM / 100)²` |

### 7.2 Fat To Lose KG

```
Se Weight KG > Target Weight:
  Fat To Lose = Weight KG - Target Weight
Senão:
  vazio
```

### 7.3 Estimated Days

```
Se Fat To Lose > 0 e Deficit Level > 0:
  Dias = (Fat To Lose × 7700) / Deficit Level
Senão:
  vazio
```

> 💡 O valor 7.700 representa as calorias aproximadas em 1 kg de gordura corporal.
> 

---

## 8. Output do Código n8n

O código retorna um objeto JSON com:

| Campo | Tipo | Descrição |
| --- | --- | --- |
| `textoParaIA` | string | Texto formatado para a IA entender a situação |
| `protocoloSugerido` | string \ | null |
| `podeEscolher` | boolean | Se o usuário pode escolher o protocolo |
| `metaTipo` | "BF" \ | "IMC" |
| `metaValor` | number | Valor numérico da meta |
| `metaAtual` | number | Valor atual da métrica (BF ou IMC) |
| `criteriosAtendidos` | string[] | Lista de critérios comportamentais OK |
| `criteriosFaltando` | string[] | Lista de critérios que faltam |

---

## 9. Integração com User Profiles

Após a análise, a tool "Atualiza User Profiles" deve gravar:

| Prop Notion | Valor do código |
| --- | --- |
| `Goal Type` | `metaTipo` |
| `Goal Value` | `metaValor` |
| `Current Protocol` | `protocoloSugerido` (se não null) |

---

## 10. Casos de Uso

### Caso 1: Usuário com BF alto

- **Input**: BF = 25%, Masculino
- **Resultado**: Recomposição obrigatória, meta BF = 20%

### Caso 2: Usuário sem BF, IMC alto

- **Input**: BF = 0 (não informado), IMC = 30.1
- **Resultado**: Recomposição obrigatória, meta IMC = 25

### Caso 3: Usuário saudável com critérios OK

- **Input**: BF = 17%, treino 4x/sem, sono 7h, alimentação estruturada
- **Resultado**: Pode escolher entre Recomposição, Ganho de Massa ou Manutenção

### Caso 4: Usuário saudável sem critérios

- **Input**: BF = 17%, treino 2x/sem
- **Resultado**: Recomposição obrigatória (falta critério de treino)

---

*Documentação atualizada em 25/01/2026*