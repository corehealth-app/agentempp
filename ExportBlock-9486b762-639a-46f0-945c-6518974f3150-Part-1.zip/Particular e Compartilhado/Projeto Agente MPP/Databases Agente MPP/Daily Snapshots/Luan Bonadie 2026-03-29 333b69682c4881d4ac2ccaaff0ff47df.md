# Luan Bonadie 2026-03-29

Calories Consumed: 585
Calories Target: 2155
Protein Target: 137,7
BMR: 1796
Daily Balance: -2198,8
Activity Level: Moderado
Activity Factor: 1,55
Current Protocol: Manutenção
Closed At: 29 de março de 2026 23:01 (BRT)
Created At: 29 de março de 2026 23:01
Date: 29 de março de 2026
Day Closed: Yes
Protein G: 36
Sleep Hours: 6,5
Training Done: No
USER-ID: USER-233
Updated At: 29 de março de 2026 23:01
XP Earned: 6

### Notas

Conversa incompleta, apenas jantar e sono registrados. Usuário não respondeu às solicitações de informações adicionais.