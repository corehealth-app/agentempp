# User Cardiocore AI

Cancel At Period End: No
Created At: 8 de abril de 2026 11:46
Current Period End: 23 de abril de 2026 23:59 (BRT)
Current Period Start: 8 de abril de 2026 11:46 (BRT)
Date_atualização: 22 de abril de 2026
Plan: Trial
Provider: Stripe
Status: Expired
Trial Ends At: 23 de abril de 2026 23:59 (BRT)
Trial Started At: 8 de abril de 2026 11:46 (BRT)
USER-ID: USER-245 
Updated At: 23 de abril de 2026 00:02
User: Cardiocore AI (../Users/Cardiocore%20AI%2033cb69682c488188842eec8930b425a1.md)
User Timezone: America/Sao_Paulo