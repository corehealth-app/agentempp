# User Thiago Cortes

Cancel At Period End: No
Created At: 25 de abril de 2026 04:18
Current Period End: 10 de maio de 2026 23:59 (BRT)
Current Period Start: 25 de abril de 2026 04:18 (BRT)
Date_atualização: 7 de maio de 2026
Plan: Trial
Provider: Stripe
Status: Trial
Trial Ends At: 10 de maio de 2026 23:59 (BRT)
Trial Started At: 25 de abril de 2026 04:18 (BRT)
USER-ID: USER-253 
Updated At: 7 de maio de 2026 00:01
User: Thiago Cortes (../Users/Thiago%20Cortes%2034db69682c48812498b7f972ab79902b.md)
User Timezone: America/Sao_Paulo