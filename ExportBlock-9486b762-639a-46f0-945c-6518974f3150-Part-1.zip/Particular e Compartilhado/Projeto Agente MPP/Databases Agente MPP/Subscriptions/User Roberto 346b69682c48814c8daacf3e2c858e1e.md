# User Roberto

Cancel At Period End: No
Created At: 18 de abril de 2026 16:49
Current Period End: 3 de maio de 2026 23:59 (BRT)
Current Period Start: 18 de abril de 2026 16:49 (BRT)
Date_atualização: 2 de maio de 2026
Plan: Trial
Provider: Stripe
Status: Expired
Trial Ends At: 3 de maio de 2026 23:59 (BRT)
Trial Started At: 18 de abril de 2026 16:49 (BRT)
USER-ID: USER-249 
Updated At: 3 de maio de 2026 00:06
User: Roberto (../Users/Roberto%20346b69682c48811c979fe941051c00ad.md)
User Timezone: America/New_york