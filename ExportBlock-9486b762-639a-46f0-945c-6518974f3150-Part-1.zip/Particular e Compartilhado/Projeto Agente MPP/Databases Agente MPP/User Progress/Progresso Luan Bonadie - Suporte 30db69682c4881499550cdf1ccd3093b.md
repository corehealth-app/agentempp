# Progresso Luan Bonadie - Suporte

Badges Earned: ["Primeiro Bloco","Streak 7 Dias","Streak 14 Dias","Proteína Master","Dia Perfeito x10","Semana Perfeita","5 Blocos","10 Blocos","Consistência Bronze","Consistência Prata","XP Master","Primeira Semana"]
Blocks Completed: 15
Current BF Percent: 28
Current Streak: 14
Current Weight: 106
Deficit Block: 1628
Last Active Date: 5 de maio de 2026 00:00 (BRT)
Level: 6
Next Reevaluation: 25 de março de 2026
USER-ID: USER-233 
Updated At: 6 de maio de 2026 00:02
User: Luan Bonadie (../Users/Luan%20Bonadie%2030db69682c48816592e7fc825345f03f.md)
XP Total: 1946