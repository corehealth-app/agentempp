# Documentação — Fluxo LLM-as-a-Judge

Este documento descreve a arquitetura e configuração do fluxo de avaliação automática de respostas de LLM usando a técnica **LLM-as-a-Judge**.

---

## Visão Geral

[Fluxo Visual](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Fluxo%20Visual%20892c80331a724626b79ecc46c9f20db6.md)

---

## Componentes

### 1. Database Notion

A database [](Avalia%C3%A7%C3%B5es%20LLM%20-%20Agente%20MPP%20332804c0815d43d7906902e9096304d5.md) armazena:

[Estrutura da Database](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Estrutura%20da%20Database%2009180dadaec34376bc0a0b7be54fbf8d.md)

---

### 2. Escala de Pontuação

[Escala de Pontuação](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Escala%20de%20Pontua%C3%A7%C3%A3o%20d2f0bf8c0ebb4bb8ad0ce635c58a6e8d.md)

---

## Configuração n8n

[Node: Notion Trigger](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20Notion%20Trigger%20e9d80b8875fb4f70a87f08ebc0adf1fd.md)

[Node: Filter](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20Filter%20f2dab34a83214a00997947bc07bb7809.md)

[Node: AI Agent](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20AI%20Agent%20ec92224e012642fc8514f1884fd6c0f9.md)

[Node: Structured Output Parser](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20Structured%20Output%20Parser%200fe68e1020f6496b8535c48f2ef55005.md)

[Node: Normalized Data (Set)](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20Normalized%20Data%20(Set)%2029167d0e580c41dca042fd9bd39de14a.md)

[Node: Notion Update](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Node%20Notion%20Update%20905813fdd86f4dd69eb643f27d4600f9.md)

---

## Prompt System do Agente Juiz

[System Prompt](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/System%20Prompt%20b1825a4a4d3b456bb3273fff0d33a7f9.md)

[User Prompt](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/User%20Prompt%20823d9d7240f6402c860fe78afb292b0d.md)

[Tool: Think (Description)](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Tool%20Think%20(Description)%2036b47f033f494f10ab4b1fe14f23cac4.md)

[Structured Output Parser (Schema)](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Structured%20Output%20Parser%20(Schema)%200998e014b05d4521801c0876122f3e5b.md)

[Normalized Data (Set) — Atualizado](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Normalized%20Data%20(Set)%20%E2%80%94%20Atualizado%20c88c290e3aab4110af4c3586b1f741aa.md)

[Notion Update — Atualizado](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Notion%20Update%20%E2%80%94%20Atualizado%203b6a719892a04e61b7d26bebc146ead7.md)

---

## Dicas e Troubleshooting

[Troubleshooting](Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge/Troubleshooting%20aafb5f3a92dd4dea95438f8be89afbbd.md)

---

## Referências

- [n8n Evaluations Overview](https://docs.n8n.io/advanced-ai/evaluations/overview)
- [Metric-based Evaluations](https://docs.n8n.io/advanced-ai/evaluations/metric-based-evaluations)
- Técnica: **LLM-as-a-Judge** (Pointwise, Reference-based)