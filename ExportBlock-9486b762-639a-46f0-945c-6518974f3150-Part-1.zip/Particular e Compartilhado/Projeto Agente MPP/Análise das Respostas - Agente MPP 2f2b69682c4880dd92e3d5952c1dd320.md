# Análise das Respostas - Agente MPP

[Documentação — Fluxo LLM-as-a-Judge](An%C3%A1lise%20das%20Respostas%20-%20Agente%20MPP/Documenta%C3%A7%C3%A3o%20%E2%80%94%20Fluxo%20LLM-as-a-Judge%20196d779309ef43efa499abbae19c5592.md)

[Avaliações LLM - Agente MPP](An%C3%A1lise%20das%20Respostas%20-%20Agente%20MPP/Avalia%C3%A7%C3%B5es%20LLM%20-%20Agente%20MPP%20332804c0815d43d7906902e9096304d5.csv)