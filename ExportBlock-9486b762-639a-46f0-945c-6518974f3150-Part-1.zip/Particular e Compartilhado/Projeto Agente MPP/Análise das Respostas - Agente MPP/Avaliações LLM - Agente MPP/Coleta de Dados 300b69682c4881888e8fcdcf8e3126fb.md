# Coleta de Dados

User Input: Fechado
Response Obtained: Perfeito! Então vamos lá:

Qual sexo biológico devemos usar para os cálculos metabólicos? (masculino/feminino)
Model Used: xiaomi/mimo-v2-flash
Session ID: chat_mpp_live_1_553291638563
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Luan Bonadie - Suporte - 553291638563
WhatsApp: 553291638563