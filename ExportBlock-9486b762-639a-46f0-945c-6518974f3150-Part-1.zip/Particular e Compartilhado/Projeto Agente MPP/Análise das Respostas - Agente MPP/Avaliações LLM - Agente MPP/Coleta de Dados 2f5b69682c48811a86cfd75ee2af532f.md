# Coleta de Dados

User Input: Pouca
Response Obtained: Você já tentou fazer dieta antes e acabou interrompendo? (sim várias vezes / sim 1–2 vezes / não)
Model Used: openai/gpt-4.1-mini
Session ID: chat_mpp_live_1_554388439898
Status: Pendente
Max Tokens: 8192
Temperature: 0,7
User: Roberto - 554388439898
WhatsApp: 554388439898